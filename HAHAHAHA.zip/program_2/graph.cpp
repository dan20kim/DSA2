#include "graph.h"
using namespace std;

Graph::Vertex::Vertex(string &tempId){
	id = tempId;
	known = false;
	dist = 0;
	Vertex* path = nullptr;
	adj.resize(0);
}

Graph::Edge::Edge(Vertex *vTemp, int tempCost){
	v = vTemp;
	cost = tempCost;
}

Graph::Graph():TableOfVertices(10000){
	listOfVertices.resize(10000);
	filled = 0;	
}

void Graph::insertVertex(string &id, string &id2, int weight){
	cout << "jakdsjf;akdlj " << endl;
/*
	if(TableOfVertices.contains(id)){
		if (TableOfVertices.contains(id2)){
			//Edge(*((Vertex*)(TableOfVertices.getPointer(id2))), weight);


			Vertex *tempVertex = ((Vertex*)TableOfVertices.getPointer(id, &a));
			cout << "hi" << endl;
			Vertex *tempVertex2 = ((Vertex*)TableOfVertices.getPointer(id2, &b));
			cout << "hi" << endl;
			Edge tempEdge = Edge(tempVertex2, weight);
			cout << "hi" << endl;
			(*tempVertex).adj.push_back(tempEdge);

			cout << "hm" << endl;
			Edge tempEdge = Edge(*((Vertex*)(TableOfVertices.getPointer(id2))),weight);
			(*((Vertex*)TableOfVertices.getPointer(id, &b))).adj.push_back(tempEdge);
			cout << "hm" << endl;



			//((Vertex*)(TableOfVertices.getPointer(id)))->adj.push_back(tempEdge);
		}
		else{//DONE
			Vertex tempVertex2 = Vertex(id2);
			listOfVertices.push_back(tempVertex2);
			TableOfVertices.insert(id2, &tempVertex2);
			Vertex *tempVertex = ((Vertex*)TableOfVertices.getPointer(id, &b));
			cout << "hm" << endl;
			Edge tempEdge = Edge(&tempVertex2, weight);
			(*tempVertex).adj.push_back(tempEdge);
			cout << "hm" << endl;
		}
		//TableOfVeddrtices.insert(id);
		//Vertex tempVertex = Vertex(id);
	}
	else{//
		if (TableOfVertices.contains(id2)){
			Vertex tempVertex = Vertex(id);
			TableOfVertices.insert(id, &tempVertex);
			Edge tempEdge = Edge(((Vertex*)(TableOfVertices.getPointer(id2, &b))), weight);
			tempVertex.adj.push_back(tempEdge);
		}
		else{//DONE
			cout <<" here" << endl;
			//Vertex 1
			listOfVertices.push_back(Vertex(id));
			TableOfVertices.insert(id, &listOfVertices.back());
			//Vertex 2
			listOfVertices.push_back(Vertex(id2));
			TableOfVertices.insert(id2, &listOfVertices.back());
			Edge tempEdge = Edge(&listOfVertices.back(), weight);
			((Vertex*)TableOfVertices.getPointer(id))->adj.push_back(tempEdge);
		}
	}
*/
	bool a;
	bool b;
	Vertex *tempVertex;
	Vertex *tempVertex2;
	if (TableOfVertices.contains(id)){
		tempVertex = (Vertex*)TableOfVertices.getPointer(id, &a);
		cout << "CASE 1" << endl;
	}
	else{
		listOfVertices[filled] = Vertex(id);
		TableOfVertices.insert(id, &listOfVertices[filled]);
		cout << "CASE 2" << endl;
		tempVertex = &listOfVertices[filled];
		filled++;
	}
	if (TableOfVertices.contains(id2)){
		tempVertex2 = (Vertex*)TableOfVertices.getPointer(id2, &b);
		cout << "CASE 3" << endl;
	}
	else{
		listOfVertices[filled] = Vertex(id2);
		TableOfVertices.insert(id2, &listOfVertices[filled]);
		tempVertex2 = &listOfVertices[filled];
		filled++;
		cout << "CASE 4" << endl;
	}
	Edge tempEdge = Edge(tempVertex2, weight);
	(*tempVertex).adj.push_back(tempEdge);
	cout << "EDGE LIST SIZE: " << (*tempVertex).adj.size() << endl;
	return;
}

void Graph::Dijkstra(string &vertexID){	
	bool b;
	heap Heap(listOfVertices.size());
	for (int i = 0; i < filled; i++){
		listOfVertices[i].dist = 1000000;
		listOfVertices[i].known = false;
		cout << listOfVertices[i].id << endl;
		Heap.insert(listOfVertices[i].id, listOfVertices[i].dist, &listOfVertices[i]);
	}
	//set input as 0 distance
	cout << "test" << endl;
	Vertex* tempVertex = (Vertex*) TableOfVertices.getPointer(vertexID, &b);
	(*tempVertex).dist = 0;
	Heap.setKey(vertexID, 0);

	for(int i = 0; i < filled; i++){
		string pId;
		int pKey;
		Vertex *v;
		cout << "hello" << endl;
		Heap.deleteMin(&pId, &pKey, v);
		cout << "world" << endl;
		cout << "test" << endl;
		cout << "filled: " << filled << endl;
		bool c;
		Vertex* tempVertex2 = (Vertex*) TableOfVertices.getPointer(pId, &c);
		(*tempVertex2).known = true;
		cout << "lol" << endl;
		for(auto it = (*tempVertex2).adj.begin(); it != (*tempVertex2).adj.end(); it++){
			if (!((*it).v->known)){
				int cvw = (*it).cost;
				if(((*tempVertex2).dist + cvw) < (*it).v->dist){
					cout << "something happened" << endl;
					(*it).v->dist = (*tempVertex2).dist + cvw;
					(*it).v->path = tempVertex2;
				}
			}
		}
	}
}

void Graph::printGraph(){
	for (int i = 0; i < filled; i++){
		cout << "hi" << endl;
		cout << printPath(listOfVertices[i].id) << endl;
	}
}

string Graph::printPath(string &id){
bool b;
	Vertex* v = (Vertex*)(TableOfVertices.getPointer(id, &b));
	string output;
	if ((*v).path != nullptr){
		cout << printPath((*((*v).path)).id) << endl;
	}
	output +=(*v).id;
	cout << output << endl;
	return output;
}
